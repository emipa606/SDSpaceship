﻿namespace Dummy
{
    internal class Dummy
    {
    }
}
